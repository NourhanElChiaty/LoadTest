/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.53888718106363, "KoPercent": 0.4611128189363664};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.17664131305044034, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.032426778242677826, 500, 1500, "addNewuser"], "isController": true}, {"data": [0.2828162291169451, 500, 1500, "-213"], "isController": false}, {"data": [0.25456389452332656, 500, 1500, "-141"], "isController": false}, {"data": [0.271875, 500, 1500, "-151"], "isController": false}, {"data": [0.2577092511013216, 500, 1500, "-184"], "isController": false}, {"data": [0.22756410256410256, 500, 1500, "-165"], "isController": false}, {"data": [0.31524249422632794, 500, 1500, "-197"], "isController": false}, {"data": [0.02385685884691849, 500, 1500, "Login"], "isController": true}, {"data": [0.25, 500, 1500, "-226"], "isController": false}, {"data": [0.04279279279279279, 500, 1500, "changeEmail"], "isController": true}, {"data": [0.0, 500, 1500, "logOut"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3253, 15, 0.4611128189363664, 1717.5856132800498, 0, 20015, 1407.0, 2951.6, 3368.2999999999997, 7268.260000000003, 8.897313027876242, 90.1733334333358, 9.09636173095543], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["addNewuser", 478, 0, 0.0, 3396.8221757322167, 0, 13454, 3039.0, 5571.700000000001, 6274.599999999999, 12630.509999999995, 1.4588114654035842, 26.95738872843065, 4.42367934454197], "isController": true}, {"data": ["-213", 419, 0, 0.0, 1690.4653937947496, 633, 6956, 1314.0, 3110.0, 3475.0, 6762.800000000002, 1.2758752991760098, 12.223148596270729, 1.2335122521330566], "isController": false}, {"data": ["-141", 493, 0, 0.0, 1754.350912778903, 816, 7414, 1469.0, 3003.2000000000007, 3202.2, 5356.600000000004, 1.3484129480464424, 15.939084445044651, 0.7687710262161016], "isController": false}, {"data": ["-151", 480, 0, 0.0, 1460.1291666666666, 626, 4772, 1323.5, 2295.4, 2471.85, 2879.9399999999996, 1.467701396150953, 14.190034627624282, 1.5823655677252464], "isController": false}, {"data": ["-184", 454, 0, 0.0, 1656.709251101321, 676, 5481, 1427.0, 2982.0, 3435.5, 5287.0, 1.3882985392286076, 13.30016375195325, 3.375843127616438], "isController": false}, {"data": ["-165", 468, 0, 0.0, 1498.9551282051273, 629, 6000, 1574.0, 2083.3, 2358.949999999999, 2938.13, 1.4318932811161424, 13.717903470543693, 1.057139961449027], "isController": false}, {"data": ["-197", 433, 0, 0.0, 1477.5311778291002, 639, 4472, 1257.0, 2704.4000000000015, 3230.5, 3519.959999999998, 1.3238877661151995, 12.683154249549785, 0.969644359947656], "isController": false}, {"data": ["Login", 503, 0, 0.0, 3281.870775347914, 0, 20015, 2834.0, 5189.400000000001, 5756.199999999995, 8243.839999999998, 1.356669121077999, 28.234646211609363, 2.1538786947656305], "isController": true}, {"data": ["-226", 406, 0, 0.0, 1861.423645320198, 670, 10510, 1505.5, 3108.3, 3668.5499999999984, 7858.0, 1.2355259353935577, 14.590599489698878, 0.8759685831012918], "isController": false}, {"data": ["changeEmail", 444, 0, 0.0, 3216.4121621621634, 0, 18656, 2618.5, 5943.5, 6759.5, 8291.050000000007, 1.3488839807875173, 24.79743243048235, 2.1941437852601005], "isController": true}, {"data": ["logOut", 418, 418, 100.0, 1843.8732057416316, 0, 10510, 1486.5, 3135.8, 4428.299999999999, 7858.0, 1.252971310554035, 14.371832561404586, 0.8628345815585403], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Response was null", 15, 100.0, 0.4611128189363664], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3253, 15, "Response was null", 15, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["logOut", 15, 15, "Response was null", 15, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
